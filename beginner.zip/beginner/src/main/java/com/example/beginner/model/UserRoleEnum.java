package com.example.beginner.model;

public enum UserRoleEnum {
    USER, // 사용자 권한
    ADMIN // 관리자 권한
}
