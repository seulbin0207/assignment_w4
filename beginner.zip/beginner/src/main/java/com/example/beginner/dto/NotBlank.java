package com.example.beginner.dto;

public @interface NotBlank {
}
