package com.example.beginner.global.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler
    public ResponseEntity<ErrorResDto> notFindUserHandler(NotFindUserException exception) {
        return ResponseEntity.ok(new ErrorResDto(exception.getMessage(), HttpStatus.BAD_REQUEST.value()));
    }

}
