package com.example.beginner.dto;

public @interface Size {
    int min();
}
