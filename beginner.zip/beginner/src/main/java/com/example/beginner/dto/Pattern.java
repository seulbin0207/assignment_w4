package com.example.beginner.dto;

public @interface Pattern {
}
