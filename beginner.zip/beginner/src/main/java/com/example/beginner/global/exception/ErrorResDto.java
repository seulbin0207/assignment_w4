package com.example.beginner.global.exception;

public class ErrorResDto {
}
